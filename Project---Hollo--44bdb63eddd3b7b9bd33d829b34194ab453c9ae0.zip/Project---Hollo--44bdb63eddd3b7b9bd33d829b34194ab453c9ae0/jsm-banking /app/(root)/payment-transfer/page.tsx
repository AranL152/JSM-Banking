import React from 'react'

const Transfer = () => {
  return (
    <div>Transfer</div>
  )
}

export default Transfer