import React from 'react'

const MyBanks = () => {
  return (
    <div>page</div>
  )
}

export default MyBanks